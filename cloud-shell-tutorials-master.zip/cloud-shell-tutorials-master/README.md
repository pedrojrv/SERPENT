# cloud-shell-tutorials

[Google Cloud Shell](https://cloud.google.com/shell/docs/) is a hosted
development environment managing resources hosted on Google Cloud Platform.

This repository contains tutorials to help you make the most of Cloud Shell.

You can find the online documentation
[here](https://cloud.google.com/shell/docs/tutorials).
Click the open in Cloud Shell button below to run a sample tutorial yourself.

[![Open this project in Cloud
Shell](http://gstatic.com/cloudssh/images/open-btn.png)](https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/GoogleCloudPlatform/cloud-shell-tutorials.git&page=editor&tutorial=tutorial.md)
