# README for hpc-monte-carlo

This directory contains the source code for calculating portfolio risk using a montecarlo model run using a HTCondor cluster on Google Cloud Platform.  See [here](https://cloud.google.com/solutions/analyzing-portfolio-risk-using-htcondor-and-compute-engine) for more details.


