var searchData=
[
  ['results',['results',['../classdecision__tree_1_1DecisionTree.html#ae34c4a8e9fb0493a7fe888646a60438d',1,'decision_tree.DecisionTree.results()'],['../classfeed__forward__nn_1_1FeedForwardNN.html#a536e87d57abf1014f02ea63249fe3e27',1,'feed_forward_nn.FeedForwardNN.results()'],['../classrandom__forest_1_1RandomForest.html#abbee4a671804976b39d8b9ec9986cab4',1,'random_forest.RandomForest.results()']]]
];
