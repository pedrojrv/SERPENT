var searchData=
[
  ['feedforwardnn',['FeedForwardNN',['../classfeed__forward__nn_1_1FeedForwardNN.html',1,'feed_forward_nn']]]
];
