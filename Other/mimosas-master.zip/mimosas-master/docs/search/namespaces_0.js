var searchData=
[
  ['decision_5ftree',['decision_tree',['../namespacedecision__tree.html',1,'']]]
];
