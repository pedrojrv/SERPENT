var searchData=
[
  ['logger',['logger',['../classdecision__tree_1_1DecisionTree.html#af5e093155e5130dd8c46b3f3afbe28fe',1,'decision_tree.DecisionTree.logger()'],['../classfeed__forward__nn_1_1FeedForwardNN.html#abbeb68f820b29d400bb86e043b043106',1,'feed_forward_nn.FeedForwardNN.logger()'],['../classrandom__forest_1_1RandomForest.html#aac4f83ac471b8183e7d3e35e44a436dd',1,'random_forest.RandomForest.logger()']]]
];
