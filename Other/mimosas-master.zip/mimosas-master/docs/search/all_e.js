var searchData=
[
  ['test',['test',['../classdecision__tree_1_1DecisionTree.html#a50041405a0c9104ef57ef431d6683952',1,'decision_tree.DecisionTree.test()'],['../classfeed__forward__nn_1_1FeedForwardNN.html#a23df0f37c1a6b2c30b41e6b778d0435f',1,'feed_forward_nn.FeedForwardNN.test()'],['../classrandom__forest_1_1RandomForest.html#a3bc06ac3e881b6e0d28b8e0aaa07c1eb',1,'random_forest.RandomForest.test()']]],
  ['train',['train',['../classdecision__tree_1_1DecisionTree.html#ae4ed64dcea1a44e7cc69b6ac1ce2cc2e',1,'decision_tree.DecisionTree.train()'],['../classfeed__forward__nn_1_1FeedForwardNN.html#a292b3bd312ecff0511b03e2bf5330495',1,'feed_forward_nn.FeedForwardNN.train()'],['../classrandom__forest_1_1RandomForest.html#a4682cfffc5ceab126f99824680077645',1,'random_forest.RandomForest.train()']]]
];
