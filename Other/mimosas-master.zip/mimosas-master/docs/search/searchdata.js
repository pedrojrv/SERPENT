var indexSectionsWithContent =
{
  0: "_abcdefghlmprst",
  1: "dfpr",
  2: "dfmpr",
  3: "dfmpr",
  4: "_abcdghlmprst",
  5: "cehlmpr",
  6: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

