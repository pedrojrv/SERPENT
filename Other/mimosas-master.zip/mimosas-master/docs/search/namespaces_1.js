var searchData=
[
  ['feed_5fforward_5fnn',['feed_forward_nn',['../namespacefeed__forward__nn.html',1,'']]]
];
