var searchData=
[
  ['permutation_5fimportance',['permutation_importance',['../classfeed__forward__nn_1_1FeedForwardNN.html#a9bef3bec9dfb18205dd108caa4dd0288',1,'feed_forward_nn::FeedForwardNN']]],
  ['print_5flicense',['print_license',['../classparameter__parser_1_1Parameters.html#a615224778f4e6601ab1c60a297493608',1,'parameter_parser::Parameters']]]
];
