var searchData=
[
  ['estimator',['estimator',['../classdecision__tree_1_1DecisionTree.html#a3e5a23e7fe5aa38de424b5db6c32f118',1,'decision_tree.DecisionTree.estimator()'],['../classfeed__forward__nn_1_1FeedForwardNN.html#ac8f35337e851130a22d3a570718c72cf',1,'feed_forward_nn.FeedForwardNN.estimator()'],['../classrandom__forest_1_1RandomForest.html#acbd6204f135714393d0921144b05fd42',1,'random_forest.RandomForest.estimator()']]]
];
