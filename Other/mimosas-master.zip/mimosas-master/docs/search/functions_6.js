var searchData=
[
  ['hyperparameter_5fspace',['hyperparameter_space',['../classfeed__forward__nn_1_1FeedForwardNN.html#a641ab1fec2799d2acc3014454b900be5',1,'feed_forward_nn::FeedForwardNN']]]
];
