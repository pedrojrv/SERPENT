var searchData=
[
  ['mimosas',['MIMOSAS',['../index.html',1,'']]]
];
