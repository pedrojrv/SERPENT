var searchData=
[
  ['background_5fcorrection',['background_correction',['../namespacepreprocessing.html#a728b810c87b6f4e389907cce1134aa7d',1,'preprocessing']]]
];
