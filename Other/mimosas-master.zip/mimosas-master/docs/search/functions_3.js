var searchData=
[
  ['construct_5fnetwork',['construct_network',['../namespacefeed__forward__nn.html#a2eaa072d6178d0609ab16b304044b6bb',1,'feed_forward_nn']]],
  ['create_5fsession_5fdirectory',['create_session_directory',['../namespacemain.html#ae207b2d234b8fa365f3434325d734073',1,'main']]]
];
