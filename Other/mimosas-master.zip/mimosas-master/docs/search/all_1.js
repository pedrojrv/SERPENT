var searchData=
[
  ['add_5fcandidate_5ffeat',['add_candidate_feat',['../classfeed__forward__nn_1_1FeedForwardNN.html#a0e756661858a0c0456b69e761c60f78e',1,'feed_forward_nn::FeedForwardNN']]]
];
