gsutil cp src/main/java/com/google/cloud/training/dataanalyst/javahelp/*.java gs://cloud-training-demos/javahelp
