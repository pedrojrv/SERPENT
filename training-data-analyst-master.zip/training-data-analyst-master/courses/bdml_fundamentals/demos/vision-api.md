## Vision API Web Demo

* Navigate to [Cloud Vision API](https://cloud.google.com/vision/#vision-api-demo)

* Find an image on the web like this one showing [Purdue university](http://www.purdue.edu/purdue/images/audience/about-banner.jpg)

* Upload the image to the web demo

* Analyze the result that is returned (object identification, web search, etc.)